﻿namespace WinFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Tbnome = new TextBox();
            Btnvalidar = new Button();
            label2 = new Label();
            Tbidade = new TextBox();
            label3 = new Label();
            Tbpeso = new TextBox();
            label4 = new Label();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            label6 = new Label();
            label5 = new Label();
            Cbsexo = new ComboBox();
            SuspendLayout();
            // 
            // Tbnome
            // 
            Tbnome.Location = new Point(47, 39);
            Tbnome.Name = "Tbnome";
            Tbnome.Size = new Size(100, 23);
            Tbnome.TabIndex = 1;
            Tbnome.Leave += Tbnome_Leave;
            // 
            // Btnvalidar
            // 
            Btnvalidar.Location = new Point(326, 366);
            Btnvalidar.Name = "Btnvalidar";
            Btnvalidar.Size = new Size(75, 23);
            Btnvalidar.TabIndex = 2;
            Btnvalidar.Text = "Cadastrar";
            Btnvalidar.UseVisualStyleBackColor = true;
            Btnvalidar.Click += Btnvalidar_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(47, 76);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 3;
            label2.Text = "sexo";
            // 
            // Tbidade
            // 
            Tbidade.Location = new Point(47, 152);
            Tbidade.Name = "Tbidade";
            Tbidade.Size = new Size(100, 23);
            Tbidade.TabIndex = 6;
            Tbidade.TextChanged += Tbidade_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(47, 134);
            label3.Name = "label3";
            label3.Size = new Size(36, 15);
            label3.TabIndex = 5;
            label3.Text = "idade";
            // 
            // Tbpeso
            // 
            Tbpeso.Location = new Point(47, 207);
            Tbpeso.Name = "Tbpeso";
            Tbpeso.Size = new Size(100, 23);
            Tbpeso.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(47, 189);
            label4.Name = "label4";
            label4.Size = new Size(32, 15);
            label4.TabIndex = 7;
            label4.Text = "Peso";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(88, 260);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(44, 19);
            radioButton1.TabIndex = 11;
            radioButton1.TabStop = true;
            radioButton1.Text = "sim";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(138, 260);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(47, 19);
            radioButton2.TabIndex = 12;
            radioButton2.TabStop = true;
            radioButton2.Text = "Não";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(47, 264);
            label6.Name = "label6";
            label6.Size = new Size(35, 15);
            label6.TabIndex = 13;
            label6.Text = "Ativo";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(47, 21);
            label5.Name = "label5";
            label5.Size = new Size(38, 15);
            label5.TabIndex = 14;
            label5.Text = "nome";
            // 
            // Cbsexo
            // 
            Cbsexo.FormattingEnabled = true;
            Cbsexo.Items.AddRange(new object[] { "Masculino", "Feminino", "Não definido" });
            Cbsexo.Location = new Point(47, 94);
            Cbsexo.Name = "Cbsexo";
            Cbsexo.Size = new Size(100, 23);
            Cbsexo.TabIndex = 15;
            Cbsexo.SelectedIndexChanged += Cbsexo_SelectedIndexChanged;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Cbsexo);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(Tbpeso);
            Controls.Add(label4);
            Controls.Add(Tbidade);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(Btnvalidar);
            Controls.Add(Tbnome);
            Name = "Form2";
            Text = "Form2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion


        private TextBox Tbnome;
        private Button Btnvalidar;
        private Label label2;
        private TextBox Tbidade;
        private Label label3;
        private TextBox Tbpeso;
        private Label label4;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private Label label6;
        private Label label5;
        private ComboBox Cbsexo;
    }
}