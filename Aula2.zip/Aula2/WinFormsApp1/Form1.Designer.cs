﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            Tblogin = new TextBox();
            label2 = new Label();
            Tbsenha = new TextBox();
            button1 = new Button();
            Lbl3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(63, 73);
            label1.Name = "label1";
            label1.Size = new Size(37, 15);
            label1.TabIndex = 0;
            label1.Text = "Login";
            label1.Click += label1_Click;
            // 
            // Tblogin
            // 
            Tblogin.Location = new Point(63, 91);
            Tblogin.Name = "Tblogin";
            Tblogin.Size = new Size(100, 23);
            Tblogin.TabIndex = 1;
            Tblogin.TextChanged += Tblogin_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(63, 136);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 2;
            label2.Text = "Senha";
            // 
            // Tbsenha
            // 
            Tbsenha.Location = new Point(63, 154);
            Tbsenha.Name = "Tbsenha";
            Tbsenha.Size = new Size(100, 23);
            Tbsenha.TabIndex = 3;
            Tbsenha.TextChanged += Tbsenha_TextChanged;
            // 
            // button1
            // 
            button1.Location = new Point(235, 330);
            button1.Name = "button1";
            button1.Size = new Size(176, 90);
            button1.TabIndex = 4;
            button1.Text = "Efetuar login";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Lbl3
            // 
            Lbl3.AutoSize = true;
            Lbl3.Location = new Point(307, 268);
            Lbl3.Name = "Lbl3";
            Lbl3.Size = new Size(38, 15);
            Lbl3.TabIndex = 5;
            Lbl3.Text = "label3";
        
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Lbl3);
            Controls.Add(button1);
            Controls.Add(Tbsenha);
            Controls.Add(label2);
            Controls.Add(Tblogin);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox Tblogin;
        private Label label2;
        private TextBox Tbsenha;
        private Button button1;
        private Label Lbl3;
    }
}
