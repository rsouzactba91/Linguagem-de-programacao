﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form2 : Form
    {
#pragma warning disable CS8618 // O campo não anulável precisa conter um valor não nulo ao sair do construtor. Considere adicionar o modificador "obrigatório" ou declarar como anulável.
        public Form2()
#pragma warning restore CS8618 // O campo não anulável precisa conter um valor não nulo ao sair do construtor. Considere adicionar o modificador "obrigatório" ou declarar como anulável.
        {
            InitializeComponent();
        }



        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Tbnome_Leave(object sender, EventArgs e)
        {
            string nome = Tbnome.Text;
            if (!string.IsNullOrEmpty(Tbnome.Text))
            {
                MessageBox.Show(Tbnome.Text);
            }
            else
            {
                MessageBox.Show("Algo está errado");
            }
        }


        private void Cbsexo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Cbsexo.SelectedItem != null)
            {
                char sexo = Cbsexo.SelectedItem.ToString()[0];
            }
            MessageBox.Show(Cbsexo.Text);
        }

        private void Tbidade_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(Tbidade.Text, out int idade))
            {
                // Use the idade variable as needed
            }
            else
            {
                // Handle the case where the text is not a valid integer
                MessageBox.Show("Por favor, insira um número válido para a idade.");
            }
            MessageBox.Show(Tbidade.Text);
        }
        private void Tbpeso_TextChanged(object sender, EventArgs e)
        {
            if (double.TryParse(Tbpeso.Text, out double peso))
            {
                // Use the peso variable as needed
            }
            else
            {
                // Handle the case where the text is not a valid double
                MessageBox.Show("Por favor, insira um número válido para o peso.");
            }
            MessageBox.Show(Tbpeso.Text);
        }

        private void Btnvalidar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Tbnome.Text + "\n" + Cbsexo.Text + "\n " + Tbidade.Text + "\n " + Tbpeso.Text);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
           radioButton1 = radioButton1sim.Text;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public string nome { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public char sexo { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public int idade { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public double peso { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public bool ativo { get; set; }
    }
}

