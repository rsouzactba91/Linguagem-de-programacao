namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Tblogin_TextChanged(object sender, EventArgs e)
        {
            string login = Tblogin.Text;
        }

        private void Tbsenha_TextChanged(object sender, EventArgs e)
        {
            string senha = Tbsenha.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            if (Tblogin.Text == "admin" && Tbsenha.Text == "admin")
            {
                MessageBox.Show("Login efetuado com sucesso!");
                form2.Show();
            }
            else
            {
                MessageBox.Show("Login ou senha incorretos!");
            }
        }

        private void UpdateLabel(object sender, EventArgs e)
        {
            // Compara��o utilizando a propriedade Text para validar as credenciais
            if (Tblogin.Text == "admin" && Tbsenha.Text == "admin")
            {
                Lbl3.Text = Tblogin.Text = "Login efetuado com sucesso!";
            }
            else
            {
                Lbl3.Text = "Login ou senha incorretos!";
            }
        }
    }

}